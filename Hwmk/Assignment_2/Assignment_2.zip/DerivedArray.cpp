/*
 * File:    DerivedArray.cpp
 * Author:  Enrique Najera
 * Purpose: Derived class prints array
 * Date:    20 September 2015
 */

// USER_LIBS
#include "DerivedArray.h"

// Start toPrint return array as QString
QString toPrint(){
    char *derArr = 0; // Placeholder for conversion

    // Output what is in array
    for (int i = 0; i < 10; ++i)
    {
        for (int j = 0; j < 10; ++j)
        {
            derArr[i];
        }
    }
} // End toPrint
